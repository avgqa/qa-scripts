import os, sys
import datetime
import ConfigParser

mySikuliPath="C:\\sikuli_scripts\\"
if not mySikuliPath in sys.path: sys.path.append(mySikuliPath)


def wait_find(y): 
    i=0
    while (not exists(y)and i<20):
        sleep(2)
        i+=1
    if exists(y,2500):
        return 1
    else: return 0

def create_installer_batch(file,dist_file):
    fo=open(dist_file, "w")
    fo.write(file)
    fo.close()

def log_write(msg):
    fo=open("C:\\sikuli_scripts\\config_setup\\local_install_log.html", "a")
    fo.write(msg)
    fo.close()

def download_installer_chrome(link):
    chrome_app="C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"  #use double slash for path 
    App.open(chrome_app)
 #   App.focus("chrome")
    sleep(10) 
    type("l", KEY_CTRL)
    type(link+"\n")
    sleep(5)
    App.close(chrome_app)
      


def installer_test(config_file, install_file):
    installer=App.open(install_file)
    App.focus(install_file)
    config=ConfigParser.ConfigParser()
    config.read(config_file)
    print "sections: " + str(config.sections()[0])
    a=config.get('installer_images_section', 'screen1')
    l=config.items('installer_images_section')
    print "a is: " + str(a)
    ll=int(len(l))/2+1
    i=1
    print "ll is: " + str(ll)
    while (i<ll):
        print "i is: " + str(i)
        screen=config.get('installer_images_section', 'screen'+str(i))
        button=config.get("installer_images_section", "button"+str(i))
        print "\nScreen is: " + str(screen) + "\n"
        print "\nButton is: " + str(button) + "\n"
        
        p=wait_find(screen)
        print "P is:" + str(p) + "\n"
        screen_in_test = capture(700,300,600,500)
        sleep(1)
        if p==0:
            #switchApp("WinZip 18")#make sure winzip screen is on top
            p=wait_find(screen)
        if p==1:
            print "\n Expected Screen " + str(Screen) + " exists!"
            print str(Screen)
            if i==2:
              #click(Pattern("1383555195877.png").targetOffset(-49,-1))
              wait_find("1383610656600.png")
              click("1383610656600.png")
            else:
                print "Ups.."
            if i==5:
             chrome_app="C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"  #use double slash for path 
             App.open(chrome_app)
             if exists("1383560192769.png",50):
                print "TB installed, test finished"         
   
             App.close(chrome_app)
            else:
             print "Ups.."            
                
            screen_in_test = capture(700,300,600,500)
            sleep(1)
           # switchApp("WinZip 18")#make sure winzip screen is on top
            q=wait_find(button)
            print "q is: " + str(q) + "\n"
            if q==1:                
                #find(button)
               # switchApp("WinZip 18")#make sure winzip screen is on top
                hover(button)
                click(button)
                
                log_write("Button " + str(i) + " is clicked!\n")
                msg='\n<h3>Expected screen is:</h3>\n<img border=\"0" src="' + str(screen) + '" alt="Expected_screen"></img>\n'
                log_write(msg)
                msg='\n<h3>Screen in Test is:</h3>\n<img border=\"0" src="' + str(screen_in_test) + '" alt="screen_in_test" width="600" height="450"></img>\n'
                log_write(msg)
                log_write("\nScreen " + str(screen) + " and button" + str(button) + " as expected: Pass!\n")
            else: 
                log_write("\n<h3> This " + str(button) + "does not exist or does not match! </h3>")
                msg='\n<h3>Screen in Test is:</h3>\n<img border=\"0" src="' + str(screen_in_test) + '" alt="screen_in_test" width="600" height="450"></img>\n'
                log_write(msg)
            sleep(2)
        
        else: 
            print "\nExpected Screen -- " + str(screen) + " does not exists!"
            log_write("\nScreen match with " + str(Screen) + "Failed: Expected Screen -- " + screen + " does not exists!")
            
            print "\nScreen in test is: " + str(screen_in_test)
            log_write("\nExpected screen is: " + str(screen_in_test))
            msg='\n<h3>Expect Screen is:</h3>\n<img border=\"0" src="' + str(screen) + '" alt="Expected_screen"></img>\n'
            log_write(msg+"\n")
        i+=1

 

#data
install_file="C:\\Users\\administrator\\Downloads\\avg_avc_oin_en_2014_v101"
install_link="http://config.inst.avg.com/serve/dl.php?pid=10864994&hash=79ce1d1af4b78a150e96966e56dc0e1d0eb715fe"
config_file="C:\\sikuli_scripts\\config_setup\\config_setup.txt"
install_batch_file="C:\\sikuli_scripts\\config_setup\\installer.bat"


log_write("<!DOCTYPE html>\n<html>\n<body>\n<P>Installation Log:</p>\n") #add </body><html> in the end of the log file later

download_installer_chrome(install_link)
create_installer_batch(install_file,install_batch_file)
sleep (10)
installer_test(config_file, install_batch_file)

log_write("</body>\n</html>")  